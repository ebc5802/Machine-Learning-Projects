import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as plt

######### Load the data ##########

infile = open('faces.csv','r')
img_data = infile.read().strip().split('\n')
img = [map(int,a.strip().split(',')) for a in img_data]
pixels = []
for p in img:
    pixels += p
faces = np.reshape(pixels,(400,4096))

######### Global Variable ##########

image_count = 0

######### Display first face #########

# Useful functions:
# > numpy.reshape(a, newshape, order='C')
#   Gives a new shape to an array without changing its data.
# > matplotlib.pyplot.figure()
# 	Creates a new figure.
# > matplotlib.pyplot.title()
#	Set a title of the current axes.
# > matplotlib.pyplot.imshow()
#	Display an image on the axes.
#	Note: You need a matplotlib.pyplot.show() at the end to display all the figures.

first_face = np.reshape(faces[0],(64,64),order='F')
image_count+=1
plt.figure(image_count)
plt.title('First_face')
plt.imshow(first_face,cmap=plt.cm.gray)

########## Display a random face ###########

# Useful functions:
# > numpy.random.choice(a, size=None, replace=True, p=None)
#   Generates a random sample from a given 1-D array
# > ndarray.reshape(shape, order='C')
#   Tuple of array dimensions.
#   Note: There are two ways to order the elements in an array: 
#         column-major order and row-major order. In np.reshape(), 
#         you can switch the order by order='C' for row-major (default), 
#         or by order='F' for column-major. 
# > numpy.reshape(a, newshape, order='C') 
#   Note: Equivalent function to numpy.reshape(a, newshape, order='C').





#### YOUR CODE HERE ####





########## compute and display the mean face ###########

# Useful functions:
# > numpy.mean(a, axis='None', ...)
#   Compute the arithmetic mean along the specified axis.
#   Returns the average of the array elements. The average is taken over 
#   the flattened array by default, otherwise over the specified axis. 
#   Note: As a sanity check you might want to print the shape of the mean face 
#   and make sure that is equal to (4096,).





#### YOUR CODE HERE ####





######### substract the mean from the face images and get the centralized data matrix A ###########

# Useful functions:
# > numpy.repeat(a, repeats, axis=None)
#   Repeat elements of an array.
#   Note: Faces is of shape (400, 4096) and mean face is of shape (4096, ).
#   As a side note you might wish to compute the centralized data matrix A without
#   using numpy.repeat(a, repeats, axis=None), but instead employing the operation 
#   of broadcasting that numpy offers.





#### YOUR CODE HERE ####





######### calculate the covariance matrix as is described in question 3 #####################

# Useful functions:
# > numpy.dot(a, b, out=None)
# Dot product of two arrays a and b. If a and b are 2-D array like in our case:
# > numpy.matmul() or @ is preferred over numpy.dot() to multiply a and b   
# > ndarray.T
#   Returns a view of the array with axes transposed.
#   Note: As a sanity check you might want to print the shape of the average
#   covariance matrix and make sure that it is equal to (64, 64). 





#### YOUR CODE HERE ####





######### calculate the eigenvalues and eigenvectors of matrix L from the tutorial #####################

# > numpy.linalg.eig(a)[source]
#   Compute the eigenvalues and right eigenvectors of a square array.
#   The eigenvalues, each repeated according to its multiplicity. 
#   The eigenvalues are not necessarily ordered. 
#   As a sanity check print the shape of the eigenvectors and eigenvalues array
#   and make sure that are equal to (400,) and (400, 400) respectively. On the 
#   hand L is a (400, 400)-matrix too.





#### YOUR CODE HERE ####





######### compute the eigenvectors of V from the tutorial through the relation that connects them with those of L #####################

# > numpy.linalg.norm(x, ord=None, axis=None, keepdims=False) 
#   This function is able to return one of eight different matrix norms, 
#   or one of an infinite number of vector norms (described below), 
#   depending on the value of the ord parameter.
#   Note: in the given function, U should be a vector, not a array. 
#         You can write your own normalize function for normalizing 
#         the columns of an array.

def normalize(U):
	return U / LA.norm(U) 





#### YOUR CODE HERE ####





########## Display the first 16 principal components ##################





#### YOUR CODE HERE ####





########## Reconstruct the first face using the first two PCs #########





#### YOUR CODE HERE ####





########## Reconstruct random face using the first 5, 10, 25, 50, 100, 200, 300, 399  PCs ###########





#### YOUR CODE HERE ####





######### Plot proportion of variance of all the PCs ###############





#### YOUR CODE HERE ####





# More useful functions:
# > matplotlib.pyplot.plot(*args, **kwargs)
#   Plot lines and/or markers to the Axes. 
# > matplotlib.pyplot.show(*args, **kw)
#   Display a figure. 





#   When running in ipython with its pylab mode, 
#   display all figures and return to the ipython prompt.
